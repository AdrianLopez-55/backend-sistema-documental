import { Controller } from '@nestjs/common';

@Controller('login')
export class LoginController {}
