

export class RoadMap {
	idRoadMap: string
	name: string
	description: string
	dateInit: string
	dateEnd: string
}
