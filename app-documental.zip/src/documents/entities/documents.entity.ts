/*
export class Document {
	id: string;
	title: string;
	author: string;
	dateModify: string;
	dateCreation: string;
	documentType: string;
	signatories: string;
	state: string
	description: string
	lastDateRetention: string;
	createAt: Date;
	updateAt: Date;
}
*/