import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Model } from "mongoose";

export type PhysicalLocationDocument = PhysicalLocation & Document

@Schema()
export class PhysicalLocation {
	@Prop()
	place: string
	@Prop()
	floor: String
	@Prop()
	office: string
	@Prop()
	saveIn: String
	@Prop()
	saveDate: Date
}

export const PhysicalLocationSchema = SchemaFactory.createForClass(PhysicalLocation);
export type PhysicalLocationModel = Model<PhysicalLocation>